import { Check, X, TrendingUp, Zap, Crown } from 'lucide-react'

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    description: 'Basic listing for small businesses',
    icon: Check,
    features: [
      { name: 'Basic business listing', included: true },
      { name: 'Contact information display', included: true },
      { name: 'Standard search visibility', included: true },
      { name: 'AI-generated content', included: true },
      { name: 'Priority search ranking', included: false },
      { name: 'Featured badge', included: false },
      { name: 'Analytics dashboard', included: false },
      { name: 'Review response tools', included: false }
    ],
    cta: 'Get Started',
    popular: false
  },
  {
    name: 'Pro',
    price: '$49',
    period: 'per month',
    description: 'Enhanced visibility and features',
    icon: TrendingUp,
    features: [
      { name: 'Everything in Free', included: true },
      { name: 'Priority search ranking (+5 boost)', included: true },
      { name: 'Pro badge on listing', included: true },
      { name: 'Analytics dashboard', included: true },
      { name: 'Review response tools', included: true },
      { name: 'Photo gallery (up to 20 images)', included: true },
      { name: 'Featured in category pages', included: false },
      { name: 'Homepage featured slot', included: false }
    ],
    cta: 'Upgrade to Pro',
    popular: true
  },
  {
    name: 'Partner+',
    price: '$199',
    period: 'per month',
    description: 'Maximum visibility and premium features',
    icon: Crown,
    features: [
      { name: 'Everything in Pro', included: true },
      { name: 'Top search ranking (+10 boost)', included: true },
      { name: 'Featured badge on listing', included: true },
      { name: 'Homepage featured slot', included: true },
      { name: 'Featured in all category pages', included: true },
      { name: 'Unlimited photos and videos', included: true },
      { name: 'Priority customer support', included: true },
      { name: 'Custom promotional campaigns', included: true }
    ],
    cta: 'Go Premium',
    popular: false
  }
]

export default function PricingPage() {
  return (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-gray-600">
            Choose the perfect plan to grow your business visibility
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.map((plan) => {
            const Icon = plan.icon
            return (
              <div
                key={plan.name}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden ${
                  plan.popular ? 'ring-4 ring-primary-600 relative' : ''
                }`}
              >
                {plan.popular && (
                  <div className="bg-primary-600 text-white text-center py-2 text-sm font-semibold">
                    Most Popular
                  </div>
                )}
                <div className="p-8">
                  <div className="flex items-center justify-center w-12 h-12 bg-primary-100 rounded-lg mb-4">
                    <Icon className="w-6 h-6 text-primary-600" />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-6">{plan.description}</p>
                  <div className="mb-6">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-gray-600 ml-2">{plan.period}</span>
                  </div>
                  <a
                    href={`/claim-business?tier=${plan.name.toLowerCase()}`}
                    className={`block w-full text-center py-3 rounded-lg font-semibold transition ${
                      plan.popular
                        ? 'bg-primary-600 text-white hover:bg-primary-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    {plan.cta}
                  </a>
                </div>
                <div className="px-8 pb-8">
                  <div className="border-t pt-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          {feature.included ? (
                            <Check className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 mr-3 mt-0.5 flex-shrink-0" />
                          )}
                          <span className={feature.included ? 'text-gray-900' : 'text-gray-400'}>
                            {feature.name}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        <div className="mt-16 max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl p-8 text-white text-center">
            <h2 className="text-3xl font-bold mb-4">Need a Custom Solution?</h2>
            <p className="text-xl mb-6 text-primary-100">
              Contact us for enterprise pricing and custom features tailored to your needs
            </p>
            <a
              href="mailto:sales@aibizdir.com"
              className="inline-block bg-white text-primary-600 px-8 py-3 rounded-lg font-semibold hover:bg-primary-50 transition"
            >
              Contact Sales
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
