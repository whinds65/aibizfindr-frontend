'use client'

import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { api } from '@/lib/supabase'
import Link from 'next/link'
import { Star, MapPin, Phone, Mail, Globe, TrendingUp } from 'lucide-react'

interface Business {
  id: string
  name: string
  slug: string
  summary: string
  description: string
  address: string
  city: string
  state: string
  phone: string
  email: string
  website: string
  rating: number
  review_count: number
  subscription_tier: string
  price_range: string
}

export default function SearchPage() {
  const searchParams = useSearchParams()
  const [businesses, setBusinesses] = useState<Business[]>([])
  const [loading, setLoading] = useState(true)
  const query = searchParams.get('q') || ''
  const location = searchParams.get('location') || ''

  useEffect(() => {
    performSearch()
  }, [query, location])

  async function performSearch() {
    setLoading(true)
    try {
      const filters: any = {}
      if (location) {
        const parts = location.split(',').map(s => s.trim())
        if (parts.length > 0) filters.city = parts[0]
        if (parts.length > 1) filters.state = parts[1]
      }

      const response = await api.search(query, filters)
      setBusinesses(response.data.results || [])
    } catch (error) {
      console.error('Search error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Search Results</h1>
        <p className="text-gray-600">
          {query && `Showing results for "${query}"`}
          {location && ` in ${location}`}
        </p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
              <div className="h-6 bg-gray-200 rounded mb-4 w-1/3"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-2/3"></div>
            </div>
          ))}
        </div>
      ) : businesses.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg mb-4">No businesses found</p>
          <p className="text-gray-400">Try adjusting your search terms or location</p>
        </div>
      ) : (
        <div className="space-y-4">
          {businesses.map((business) => (
            <Link
              key={business.id}
              href={`/business/${business.slug}`}
              className="block bg-white rounded-lg shadow-sm hover:shadow-md transition p-6"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  {business.subscription_tier !== 'free' && (
                    <div className="inline-flex items-center text-primary-600 text-sm font-semibold mb-2">
                      <TrendingUp className="w-4 h-4 mr-1" />
                      {business.subscription_tier === 'partner_plus' ? 'Featured' : 'Pro'}
                    </div>
                  )}
                  <h2 className="text-2xl font-semibold text-gray-900 hover:text-primary-600 transition">
                    {business.name}
                  </h2>
                </div>
                <div className="flex items-center">
                  <Star className="w-5 h-5 text-yellow-400 fill-current" />
                  <span className="ml-1 font-semibold">{business.rating}</span>
                  <span className="ml-2 text-sm text-gray-500">
                    ({business.review_count} reviews)
                  </span>
                </div>
              </div>

              <p className="text-gray-600 mb-4">{business.summary}</p>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center text-gray-600">
                  <MapPin className="w-4 h-4 mr-2" />
                  {business.address}, {business.city}, {business.state}
                </div>
                {business.phone && (
                  <div className="flex items-center text-gray-600">
                    <Phone className="w-4 h-4 mr-2" />
                    {business.phone}
                  </div>
                )}
                {business.email && (
                  <div className="flex items-center text-gray-600">
                    <Mail className="w-4 h-4 mr-2" />
                    {business.email}
                  </div>
                )}
                {business.website && (
                  <div className="flex items-center text-primary-600">
                    <Globe className="w-4 h-4 mr-2" />
                    Visit Website
                  </div>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
