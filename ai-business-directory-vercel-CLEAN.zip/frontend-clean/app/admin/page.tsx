'use client'

import { useEffect, useState } from 'react'
import { api } from '@/lib/supabase'
import { RefreshCw, Clock, CheckCircle, XCircle, AlertCircle, Plus } from 'lucide-react'

interface Job {
  id: string
  job_type: string
  status: string
  progress: number
  total_items: number
  processed_items: number
  failed_items: number
  error_message: string
  created_at: string
}

export default function AdminDashboard() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    loadJobs()
    const interval = setInterval(loadJobs, 5000) // Refresh every 5 seconds
    return () => clearInterval(interval)
  }, [filter])

  async function loadJobs() {
    try {
      const filters = filter !== 'all' ? { status: filter } : {}
      const response = await api.getJobs(filters)
      setJobs(response.data || [])
    } catch (error) {
      console.error('Error loading jobs:', error)
    } finally {
      setLoading(false)
    }
  }

  async function createNewJob(jobType: string) {
    try {
      await api.createJob(jobType, {}, 'admin')
      loadJobs()
    } catch (error) {
      console.error('Error creating job:', error)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-600" />
      case 'processing':
        return <RefreshCw className="w-5 h-5 text-blue-600 animate-spin" />
      default:
        return <Clock className="w-5 h-5 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800'
      case 'failed':
        return 'bg-red-100 text-red-800'
      case 'processing':
        return 'bg-blue-100 text-blue-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
        <p className="text-gray-600">Manage jobs and monitor system operations</p>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <button
          onClick={() => createNewJob('ai_enrich')}
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-left"
        >
          <Plus className="w-6 h-6 text-primary-600 mb-2" />
          <h3 className="font-semibold mb-1">AI Enrichment</h3>
          <p className="text-sm text-gray-600">Enrich business listings</p>
        </button>
        <button
          onClick={() => createNewJob('reindex')}
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-left"
        >
          <RefreshCw className="w-6 h-6 text-primary-600 mb-2" />
          <h3 className="font-semibold mb-1">Reindex Search</h3>
          <p className="text-sm text-gray-600">Update search index</p>
        </button>
        <button
          onClick={() => createNewJob('csv_import')}
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-left"
        >
          <Plus className="w-6 h-6 text-primary-600 mb-2" />
          <h3 className="font-semibold mb-1">Import CSV</h3>
          <p className="text-sm text-gray-600">Bulk import businesses</p>
        </button>
        <button
          onClick={() => createNewJob('web_scrape')}
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-left"
        >
          <Plus className="w-6 h-6 text-primary-600 mb-2" />
          <h3 className="font-semibold mb-1">Web Scrape</h3>
          <p className="text-sm text-gray-600">Scrape business data</p>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex gap-2">
          {['all', 'pending', 'processing', 'completed', 'failed'].map((status) => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                filter === status
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Jobs List */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-500">Loading jobs...</div>
        ) : jobs.length === 0 ? (
          <div className="p-8 text-center text-gray-500">No jobs found</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Job Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Progress
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Items
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Created
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Details
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {jobs.map((job) => (
                  <tr key={job.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {getStatusIcon(job.status)}
                        <span className={`ml-2 px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(job.status)}`}>
                          {job.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm font-medium text-gray-900">
                        {job.job_type.replace('_', ' ').toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-primary-600 h-2 rounded-full transition-all"
                          style={{ width: `${job.progress}%` }}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-500 mt-1">{job.progress}%</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {job.processed_items}/{job.total_items}
                      {job.failed_items > 0 && (
                        <span className="text-red-600 ml-2">({job.failed_items} failed)</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(job.created_at).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {job.error_message && (
                        <div className="flex items-center text-red-600">
                          <AlertCircle className="w-4 h-4 mr-1" />
                          <span className="truncate max-w-xs" title={job.error_message}>
                            {job.error_message}
                          </span>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
