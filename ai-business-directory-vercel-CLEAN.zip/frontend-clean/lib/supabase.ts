// Supabase client configuration
import { createClient } from '@supabase/supabase-js'

// PLACEHOLDER: Replace with your Supabase credentials
// Get these from Supabase dashboard after project setup
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// API endpoints for edge functions
const FUNCTIONS_URL = `${supabaseUrl}/functions/v1`

export const api = {
  // Businesses
  async getBusinesses(filters?: any) {
    const { data, error } = await supabase.functions.invoke('businesses-api', {
      body: { ...filters },
      method: 'GET'
    })
    if (error) throw error
    return data
  },

  async getBusiness(slug: string) {
    const { data, error } = await supabase.functions.invoke(`businesses-api`, {
      body: { slug },
      method: 'GET'
    })
    if (error) throw error
    return data
  },

  async createBusiness(businessData: any) {
    const { data, error } = await supabase.functions.invoke('businesses-api', {
      body: businessData,
      method: 'POST'
    })
    if (error) throw error
    return data
  },

  async updateBusiness(id: string, updates: any) {
    const { data, error } = await supabase.functions.invoke(`businesses-api`, {
      body: { id, ...updates },
      method: 'PUT'
    })
    if (error) throw error
    return data
  },

  // Search
  async search(query: string, filters?: any) {
    const { data, error } = await supabase.functions.invoke('search-businesses', {
      body: { query, filters }
    })
    if (error) throw error
    return data
  },

  // Business Claims
  async createClaim(businessId: string, email: string, name: string) {
    const { data, error } = await supabase.functions.invoke('business-claim', {
      body: {
        business_id: businessId,
        claimer_email: email,
        claimer_name: name
      }
    })
    if (error) throw error
    return data
  },

  async verifyClaim(token: string) {
    const { data, error } = await supabase.functions.invoke('business-claim', {
      body: { token },
      method: 'GET'
    })
    if (error) throw error
    return data
  },

  // AI Assistant
  async chatWithAssistant(query: string, conversationHistory?: any[]) {
    const { data, error } = await supabase.functions.invoke('ai-assistant', {
      body: { query, conversation_history: conversationHistory }
    })
    if (error) throw error
    return data
  },

  // Subscriptions
  async createCheckout(userId: string, businessId: string, tier: string) {
    const { data, error } = await supabase.functions.invoke('subscription-api', {
      body: {
        user_id: userId,
        business_id: businessId,
        tier,
        success_url: `${window.location.origin}/subscription/success`,
        cancel_url: `${window.location.origin}/subscription/cancel`
      }
    })
    if (error) throw error
    return data
  },

  async getSubscription(businessId: string) {
    const { data, error } = await supabase.functions.invoke('subscription-api', {
      body: { business_id: businessId },
      method: 'GET'
    })
    if (error) throw error
    return data
  },

  // Jobs (Admin)
  async createJob(jobType: string, inputData: any, createdBy?: string) {
    const { data, error } = await supabase.functions.invoke('job-management', {
      body: {
        job_type: jobType,
        input_data: inputData,
        created_by: createdBy
      }
    })
    if (error) throw error
    return data
  },

  async getJobs(filters?: any) {
    const { data, error } = await supabase.functions.invoke('job-management', {
      body: filters,
      method: 'GET'
    })
    if (error) throw error
    return data
  },

  async getJobStatus(jobId: string) {
    const { data, error } = await supabase.functions.invoke('job-management', {
      body: { job_id: jobId },
      method: 'GET'
    })
    if (error) throw error
    return data
  }
}
