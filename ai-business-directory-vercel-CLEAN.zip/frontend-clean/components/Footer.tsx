import Link from 'next/link'
import { Building2, Github, Twitter, Linkedin } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Building2 className="w-6 h-6 text-primary-400" />
              <span className="text-xl font-bold text-white">
                AI Business Directory
              </span>
            </div>
            <p className="text-sm text-gray-400">
              Discover and connect with local businesses powered by AI search and recommendations.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/search" className="hover:text-primary-400 transition">
                  Search Businesses
                </Link>
              </li>
              <li>
                <Link href="/categories" className="hover:text-primary-400 transition">
                  Browse Categories
                </Link>
              </li>
              <li>
                <Link href="/assistant" className="hover:text-primary-400 transition">
                  AI Assistant
                </Link>
              </li>
              <li>
                <Link href="/claim-business" className="hover:text-primary-400 transition">
                  Claim Your Business
                </Link>
              </li>
            </ul>
          </div>

          {/* For Business */}
          <div>
            <h3 className="font-semibold text-white mb-4">For Business</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/pricing" className="hover:text-primary-400 transition">
                  Pricing Plans
                </Link>
              </li>
              <li>
                <Link href="/claim-business" className="hover:text-primary-400 transition">
                  Claim Listing
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-primary-400 transition">
                  Business Dashboard
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/privacy" className="hover:text-primary-400 transition">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-primary-400 transition">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/dsar" className="hover:text-primary-400 transition">
                  Data Rights (DSAR)
                </Link>
              </li>
              <li>
                <Link href="/robots.txt" className="hover:text-primary-400 transition">
                  Robots.txt
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-400">
            © 2025 AI Business Directory. All rights reserved.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-primary-400 transition">
              <Twitter className="w-5 h-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-primary-400 transition">
              <Linkedin className="w-5 h-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-primary-400 transition">
              <Github className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
