'use client'

import { useEffect, useState } from 'react'
import { api } from '@/lib/supabase'
import Link from 'next/link'
import { Star, MapPin, TrendingUp } from 'lucide-react'

interface Business {
  id: string
  name: string
  slug: string
  summary: string
  city: string
  state: string
  rating: number
  review_count: number
  subscription_tier: string
}

export default function FeaturedBusinesses() {
  const [businesses, setBusinesses] = useState<Business[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadFeaturedBusinesses()
  }, [])

  async function loadFeaturedBusinesses() {
    try {
      const response = await api.getBusinesses({ tier: 'partner_plus', limit: 6 })
      setBusinesses(response.data || [])
    } catch (error) {
      console.error('Error loading featured businesses:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="grid md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
            <div className="h-6 bg-gray-200 rounded mb-4"></div>
            <div className="h-4 bg-gray-200 rounded mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        ))}
      </div>
    )
  }

  if (businesses.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <p>No featured businesses available</p>
      </div>
    )
  }

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {businesses.map((business) => (
        <Link
          key={business.id}
          href={`/business/${business.slug}`}
          className="bg-white rounded-lg shadow-sm hover:shadow-md transition p-6 group"
        >
          {business.subscription_tier === 'partner_plus' && (
            <div className="flex items-center text-primary-600 text-sm font-semibold mb-2">
              <TrendingUp className="w-4 h-4 mr-1" />
              Featured
            </div>
          )}
          <h3 className="text-xl font-semibold mb-2 group-hover:text-primary-600 transition">
            {business.name}
          </h3>
          <div className="flex items-center text-sm text-gray-600 mb-3">
            <MapPin className="w-4 h-4 mr-1" />
            {business.city}, {business.state}
          </div>
          <div className="flex items-center mb-3">
            <div className="flex items-center">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="ml-1 text-sm font-semibold">{business.rating}</span>
            </div>
            <span className="ml-2 text-sm text-gray-500">
              ({business.review_count} reviews)
            </span>
          </div>
          <p className="text-gray-600 text-sm line-clamp-2">{business.summary}</p>
        </Link>
      ))}
    </div>
  )
}
