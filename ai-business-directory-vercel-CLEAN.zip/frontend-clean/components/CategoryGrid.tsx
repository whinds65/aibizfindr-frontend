'use client'

import Link from 'next/link'
import {
  Utensils,
  Heart,
  ShoppingBag,
  Briefcase,
  Home,
  Car,
  Sparkles,
  GraduationCap,
  Ticket,
  Laptop,
  Building,
  DollarSign
} from 'lucide-react'

const categories = [
  { name: 'Restaurants', slug: 'restaurants', icon: Utensils, color: 'bg-red-100 text-red-600' },
  { name: 'Healthcare', slug: 'healthcare', icon: Heart, color: 'bg-pink-100 text-pink-600' },
  { name: 'Retail', slug: 'retail', icon: ShoppingBag, color: 'bg-purple-100 text-purple-600' },
  { name: 'Professional Services', slug: 'professional-services', icon: Briefcase, color: 'bg-blue-100 text-blue-600' },
  { name: 'Home Services', slug: 'home-services', icon: Home, color: 'bg-green-100 text-green-600' },
  { name: 'Automotive', slug: 'automotive', icon: Car, color: 'bg-gray-100 text-gray-600' },
  { name: 'Beauty & Wellness', slug: 'beauty-wellness', icon: Sparkles, color: 'bg-yellow-100 text-yellow-600' },
  { name: 'Education', slug: 'education', icon: GraduationCap, color: 'bg-indigo-100 text-indigo-600' },
  { name: 'Entertainment', slug: 'entertainment', icon: Ticket, color: 'bg-orange-100 text-orange-600' },
  { name: 'Technology', slug: 'technology', icon: Laptop, color: 'bg-cyan-100 text-cyan-600' },
  { name: 'Real Estate', slug: 'real-estate', icon: Building, color: 'bg-teal-100 text-teal-600' },
  { name: 'Financial Services', slug: 'financial-services', icon: DollarSign, color: 'bg-emerald-100 text-emerald-600' }
]

export default function CategoryGrid() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
      {categories.map((category) => {
        const Icon = category.icon
        return (
          <Link
            key={category.slug}
            href={`/category/${category.slug}`}
            className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center group"
          >
            <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-3 ${category.color}`}>
              <Icon className="w-6 h-6" />
            </div>
            <h3 className="font-semibold text-gray-900 group-hover:text-primary-600 transition">
              {category.name}
            </h3>
          </Link>
        )
      })}
    </div>
  )
}
